package com.books.store_books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
